UpUp.start({
    // 'content-url': 'offline.html'
    //,
    'assets': ['index.html', 
               'css/materialize.min.css',
               'css/estilos.css',
               'images/taskit-icon-64.gif',
               'images/taskit-icon-64.png',
               'images/taskit-icon-96.png',
               'images/taskit-icon-128.png',
               'images/taskit-icon-144.png',
               'images/taskit-icon-512.png',
               'js/materialize.min.js',
               'js/JQuery-3.5.1.min.js',
               'js/tareas.js',
               'manifest.json',
               'offline.js',
               'upup.sw.min.js',
               'upup.js']
  });